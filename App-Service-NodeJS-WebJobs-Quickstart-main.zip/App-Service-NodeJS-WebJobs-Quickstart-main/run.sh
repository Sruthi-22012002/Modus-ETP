#!/bin/bash

node webjob.js